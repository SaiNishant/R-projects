# Suicides-Analysis-in-India-
Suicide is the act of intentionally causing one's own death. Depression, bipolar disorder, schizophrenia, personality disorders, and substance abuse including alcoholism and the use of benzodiazepinesare risk factors
